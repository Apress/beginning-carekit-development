# A Careplan server

## Installing Node
Node.js is very easy to install. If you're using Windows or Mac, installers are available on the [download page](https://nodejs.org).


## Install Careplan packages
Now that you have Node installed an running you need to install the node packages included with the careplan service.  Run the following node command from within the careplanservice directory

'''
cd careplanservice
npm install
npm start
'''

Your app should now be running on [localhost:8081](http:localhost:8081)


#Test

click the following link in your browser

[CarePlan Service](http://localhost:8081/careplan)

You now see the JSON response with the example careplan.
